'use client'
import { useState, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { Phone, Mail, MapPin, MessageCircle, CheckCircle, Clock, Truck } from 'lucide-react'

const products = [
  'Bột Sắn Dây Nguyên Chất 500g — 85.000₫',
  'Bột Sắn Dây Nguyên Chất 1kg — 155.000₫',
  'Combo 3 túi 500g (Tặng 1) — 230.000₫',
  'Bột Sắn Dây Hộp Quà 2 x 500g — 195.000₫',
]

const paymentMethods = [
  { id: 'momo', label: 'MoMo', icon: '💜', account: '0901 234 567' },
  { id: 'zalo', label: 'ZaloPay', icon: '💙', account: '0901 234 567' },
  { id: 'bank', label: 'Chuyển khoản', icon: '🏦', account: 'VCB — 1234567890 — Nguyễn Thị Năm' },
  { id: 'cod', label: 'COD (Nhận hàng trả tiền)', icon: '💵', account: 'Trả tiền khi nhận hàng' },
]

function ContactForm() {
  const searchParams = useSearchParams()
  const preselectedProduct = searchParams.get('product') || ''

  const [form, setForm] = useState({
    name: '',
    phone: '',
    address: '',
    product: preselectedProduct
      ? products.find(p => p.startsWith(preselectedProduct)) || products[0]
      : products[0],
    quantity: '1',
    payment: 'momo',
    note: '',
  })
  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm(f => ({ ...f, [e.target.name]: e.target.value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In production: send to API / Zalo OA / email
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div className="text-center py-16 px-4">
        <div className="w-20 h-20 bg-brand-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-10 h-10 text-brand-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-3">Đặt hàng thành công! 🎉</h2>
        <p className="text-gray-500 max-w-md mx-auto mb-6">
          Cảm ơn <strong>{form.name}</strong>! Chúng tôi sẽ liên hệ xác nhận đơn hàng trong vòng 30 phút qua số <strong>{form.phone}</strong>.
        </p>
        <div className="bg-brand-50 rounded-2xl p-6 max-w-sm mx-auto text-left mb-8">
          <h3 className="font-bold text-gray-800 mb-3">Thông tin thanh toán:</h3>
          {(() => {
            const pm = paymentMethods.find(p => p.id === form.payment)
            return pm ? (
              <div className="flex items-center gap-3">
                <span className="text-2xl">{pm.icon}</span>
                <div>
                  <div className="font-semibold text-gray-700">{pm.label}</div>
                  <div className="text-sm text-gray-500 font-mono">{pm.account}</div>
                </div>
              </div>
            ) : null
          })()}
        </div>
        <button
          onClick={() => setSubmitted(false)}
          className="btn-outline"
        >
          Đặt thêm đơn mới
        </button>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="grid md:grid-cols-2 gap-5">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">Họ và tên *</label>
          <input
            type="text"
            name="name"
            required
            value={form.name}
            onChange={handleChange}
            placeholder="Nguyễn Văn A"
            className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-transparent transition"
          />
        </div>
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">Số điện thoại *</label>
          <input
            type="tel"
            name="phone"
            required
            value={form.phone}
            onChange={handleChange}
            placeholder="0901 234 567"
            className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-transparent transition"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-1.5">Địa chỉ giao hàng *</label>
        <input
          type="text"
          name="address"
          required
          value={form.address}
          onChange={handleChange}
          placeholder="Số nhà, đường, phường/xã, quận/huyện, tỉnh/thành phố"
          className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-transparent transition"
        />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">Sản phẩm *</label>
          <select
            name="product"
            value={form.product}
            onChange={handleChange}
            className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-transparent transition bg-white"
          >
            {products.map(p => <option key={p} value={p}>{p}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">Số lượng *</label>
          <select
            name="quantity"
            value={form.quantity}
            onChange={handleChange}
            className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-transparent transition bg-white"
          >
            {['1','2','3','4','5','6','10'].map(n => <option key={n} value={n}>{n} {Number(n) > 1 ? 'sản phẩm' : 'sản phẩm'}</option>)}
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-3">Phương thức thanh toán *</label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {paymentMethods.map(pm => (
            <label
              key={pm.id}
              className={`relative flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 cursor-pointer transition-all ${
                form.payment === pm.id
                  ? 'border-brand-500 bg-brand-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="radio"
                name="payment"
                value={pm.id}
                checked={form.payment === pm.id}
                onChange={handleChange}
                className="sr-only"
              />
              <span className="text-2xl">{pm.icon}</span>
              <span className="text-xs font-semibold text-gray-700 text-center">{pm.label}</span>
              {form.payment === pm.id && (
                <CheckCircle className="w-4 h-4 text-brand-500 absolute top-2 right-2" />
              )}
            </label>
          ))}
        </div>
        {form.payment && (
          <div className="mt-3 bg-gray-50 rounded-xl p-4 text-sm">
            <span className="font-semibold text-gray-700">Thông tin thanh toán: </span>
            <span className="text-gray-500 font-mono">{paymentMethods.find(p => p.id === form.payment)?.account}</span>
          </div>
        )}
      </div>

      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-1.5">Ghi chú (tùy chọn)</label>
        <textarea
          name="note"
          value={form.note}
          onChange={handleChange}
          rows={3}
          placeholder="Ghi chú về đơn hàng, thời gian giao hàng, hoặc yêu cầu đặc biệt..."
          className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-transparent transition resize-none"
        />
      </div>

      <button type="submit" className="w-full btn-primary justify-center py-4 text-base">
        Xác nhận đặt hàng 🛍️
      </button>
      <p className="text-xs text-gray-400 text-center">
        Chúng tôi sẽ liên hệ xác nhận trong vòng 30 phút trong giờ hành chính
      </p>
    </form>
  )
}

export default function ContactPage() {
  return (
    <>
      {/* Header */}
      <section className="bg-gradient-to-br from-brand-50 to-white py-14 text-center">
        <div className="max-w-3xl mx-auto px-4">
          <span className="badge mb-4">📦 Đặt hàng</span>
          <h1 className="section-title">Đặt Hàng & Liên Hệ</h1>
          <p className="text-gray-500 text-lg">Điền form bên dưới, chúng tôi xác nhận trong 30 phút</p>
        </div>
      </section>

      <section className="bg-gray-50 py-16">
        <div className="max-w-6xl mx-auto px-4 grid lg:grid-cols-3 gap-10">
          {/* Form */}
          <div className="lg:col-span-2 bg-white rounded-3xl shadow-sm p-8">
            <h2 className="text-xl font-bold text-gray-800 mb-6">Thông tin đặt hàng</h2>
            <Suspense fallback={<div className="text-gray-400 text-sm">Đang tải form...</div>}>
              <ContactForm />
            </Suspense>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact info */}
            <div className="bg-white rounded-3xl shadow-sm p-6">
              <h3 className="font-bold text-gray-800 mb-5">Liên hệ trực tiếp</h3>
              <div className="space-y-4">
                <a href="tel:0901234567" className="flex items-center gap-3 text-sm text-gray-600 hover:text-brand-600 transition-colors">
                  <div className="w-9 h-9 bg-brand-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Phone className="w-4 h-4 text-brand-600" />
                  </div>
                  <div>
                    <div className="font-semibold">Gọi điện</div>
                    <div className="text-brand-600">0901 234 567</div>
                  </div>
                </a>
                <a href="https://zalo.me/0901234567" className="flex items-center gap-3 text-sm text-gray-600 hover:text-brand-600 transition-colors">
                  <div className="w-9 h-9 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <MessageCircle className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <div className="font-semibold">Zalo</div>
                    <div className="text-blue-600">0901 234 567</div>
                  </div>
                </a>
                <a href="mailto:hello@sandayque.vn" className="flex items-center gap-3 text-sm text-gray-600 hover:text-brand-600 transition-colors">
                  <div className="w-9 h-9 bg-brand-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Mail className="w-4 h-4 text-brand-600" />
                  </div>
                  <div>
                    <div className="font-semibold">Email</div>
                    <div className="text-brand-600">hello@sandayque.vn</div>
                  </div>
                </a>
                <div className="flex items-start gap-3 text-sm text-gray-600">
                  <div className="w-9 h-9 bg-brand-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-4 h-4 text-brand-600" />
                  </div>
                  <div>
                    <div className="font-semibold">Địa chỉ</div>
                    <div className="text-gray-500">Thôn Phú An, Xã Bình Hòa,<br />Tỉnh Quảng Ngãi</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Hours */}
            <div className="bg-white rounded-3xl shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <Clock className="w-4 h-4 text-brand-500" />
                <h3 className="font-bold text-gray-800">Giờ làm việc</h3>
              </div>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex justify-between">
                  <span>Thứ 2 — Thứ 6</span>
                  <span className="font-semibold text-brand-600">8:00 — 21:00</span>
                </div>
                <div className="flex justify-between">
                  <span>Thứ 7 — Chủ nhật</span>
                  <span className="font-semibold text-brand-600">8:00 — 18:00</span>
                </div>
              </div>
            </div>

            {/* Shipping */}
            <div className="bg-brand-50 rounded-3xl p-6">
              <div className="flex items-center gap-2 mb-4">
                <Truck className="w-4 h-4 text-brand-600" />
                <h3 className="font-bold text-gray-800">Chính sách vận chuyển</h3>
              </div>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-brand-500 flex-shrink-0 mt-0.5" /> Giao toàn quốc qua GHN, GHTK</li>
                <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-brand-500 flex-shrink-0 mt-0.5" /> <strong>Miễn phí ship</strong> đơn từ 300.000₫</li>
                <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-brand-500 flex-shrink-0 mt-0.5" /> Giao trong 2–4 ngày làm việc</li>
                <li className="flex gap-2"><CheckCircle className="w-4 h-4 text-brand-500 flex-shrink-0 mt-0.5" /> Hoàn tiền 100% nếu sản phẩm lỗi</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
